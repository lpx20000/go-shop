/**
 * 配置文件
 */
module.exports = {
  name: "萤火小程序商城",
  siteroot: "http://127.0.0.1:8000/api/v1/", // 必填: api地址，结尾要带/
};